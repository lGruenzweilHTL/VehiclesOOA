namespace VehicleModel;

public enum FuelType
{
    Gasoline, Diesel, Electric
}
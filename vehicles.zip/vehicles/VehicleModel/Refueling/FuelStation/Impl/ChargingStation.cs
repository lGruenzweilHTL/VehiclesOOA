namespace VehicleModel;

public class ChargingStation : FuelStation
{
    public ChargingStation() : base(FuelType.Electric)
    {
    }
}
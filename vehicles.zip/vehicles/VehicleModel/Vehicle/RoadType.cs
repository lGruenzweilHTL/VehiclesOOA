namespace VehicleModel;

public enum RoadType
{
    CityRoad, Highway, Backroad, Offroad
}